#' CIMICE Package
#'
#' CIMICE-R: (Markov) Chain Method to Inferr Cancer Evolution
#'
#' @description R implementation of the CIMICE tool
#'
#' @docType package
#'
#' @author Nicolò Rossi \email{olocin.issor@gmail.com}
#'
#' @name CIMICE
#'
#'
NULL
